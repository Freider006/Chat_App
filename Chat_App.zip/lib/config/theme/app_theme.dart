import 'package:flutter/material.dart';

const List<Color> _colorTheme = [
  Colors.indigo,
  Colors.cyanAccent,
  Colors.green,
  Colors.yellow,
  Colors.orange,
  Colors.pink,
  Colors.red,
  Colors.blue,
  Colors.teal,
  Colors.purple,
];

class AppTheme {
  final int selectColor;

  AppTheme({this.selectColor = 0})
      : assert(
          selectColor >= 0 && selectColor < _colorTheme.length,
          'El valor designado no está en el rango de los colores de la lista. '
          'Debe estar entre 0 y ${_colorTheme.length - 1}',
        );

  ThemeData theme() {
    return ThemeData(
      useMaterial3: true,
      colorSchemeSeed: _colorTheme[selectColor],
    );
  }
}

