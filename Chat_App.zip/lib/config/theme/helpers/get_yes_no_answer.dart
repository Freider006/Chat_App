import 'package:dio/dio.dart';

import '../../../Domain/entities/message_entity.dart';
import '../../../infrastructure/model/yes_no_model.dart';

class GetYesNoAnswer {
  final dio = Dio();

  Future<Message> getAnswer() async {
    final response = await dio.get('https://yesno.wtf/api');

    final yesNoModel = YesNoModel.fromJsonMap(response.data);

    return yesNoModel.toMessageEntity();
  }
}
