import 'package:flutter/material.dart';
import 'package:chat_app/Domain/entities/message_entity.dart'
    show FromWho, Message;

import 'package:chat_app/config/theme/helpers/get_yes_no_answer.dart';

class ChatProvider extends ChangeNotifier {
  final ScrollController chatScrollController = ScrollController();
  final GetYesNoAnswer getYesNoAnswer = GetYesNoAnswer();

  List<Message> messageList = [
    Message(text: 'Bienvenido al chat', fromWho: FromWho.mine),
    Message(text: '¿Te encuentras bien?', fromWho: FromWho.mine),
  ];

  Future<void> sendMessage(String text) async {
    if (text.isEmpty) return;

    final newMessage = Message(text: text, fromWho: FromWho.mine);
    messageList.add(newMessage);

    notifyListeners();
    moveScrollToBottom();

    if (text.endsWith('?')) {
      await herReply();
    }
  }

  Future<void> herReply() async {
    final hersMessage = await getYesNoAnswer.getAnswer();
    messageList.add(hersMessage);

    notifyListeners();
    moveScrollToBottom();
  }

  Future<void> moveScrollToBottom() async {
    await Future.delayed(const Duration(milliseconds: 100));
    chatScrollController.animateTo(
      chatScrollController.position.maxScrollExtent,
      duration: const Duration(milliseconds: 250),
      curve: Curves.easeInOut,
    );
  }
}
