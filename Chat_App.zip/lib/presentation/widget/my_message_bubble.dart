import 'package:flutter/material.dart';

import '../../Domain/entities/message_entity.dart';

class MyMessageBubble extends StatelessWidget {
  final Message messageText;

  const MyMessageBubble({super.key, required this.messageText});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Container(
          decoration: BoxDecoration(
            color: colors.primary,
            borderRadius: BorderRadius.circular(20),
          ), // BoxDecoration
          child: Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: 20,
              vertical: 10,
            ), // EdgeInsets.symmetric
            child: Text(
              'Mis propios mensajes',
              style: const TextStyle(color: Colors.white),
            ), // Text
          ), // Padding
        ), // Container
        const SizedBox(height: 10),
      ],
    ); // Column
  }
}
