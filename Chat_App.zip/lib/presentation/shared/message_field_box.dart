import 'package:flutter/material.dart';

class MessageFieldBox extends StatelessWidget {
  final ValueChanged<String> onValue;

  const MessageFieldBox({super.key, required this.onValue});

  @override
  Widget build(BuildContext context) {
    // Elemento que me permite tener control sobre input (valor, limpiar)
    final textController = TextEditingController();
    final focusNode = FocusNode();
    final outlineInput = UnderlineInputBorder(
      borderSide: const BorderSide(color: Colors.pink),
      borderRadius: BorderRadius.circular(40),
    );

    final inputDecoration = InputDecoration(
      hintText: 'Ingresar un mensaje, respuesta al terminar en "?"',
      focusedBorder: outlineInput,
      enabledBorder: outlineInput,
      filled: true,
      suffixIcon: IconButton(
        icon: const Icon(Icons.send_outlined),
        onPressed: () {
          final textValue = textController.value.text;
          onValue(textValue);
          textController.clear();
        },
      ), // IconButton
    ); // InputDecoration

    return TextFormField(
      onTapOutside: (event) {
        focusNode.unfocus();
      },
      focusNode: focusNode,
      controller: textController,
      decoration: inputDecoration,
      onFieldSubmitted: (value) {
        onValue(value);
        textController.clear();
        focusNode.requestFocus();
      },
    );
  }
}
